﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    class EmployeeLogic: IEmployeeLogic
    {
        /// <summary>
        /// Adding the Employee into the list
        /// </summary>
        /// <param name="employee"></param>
        /// <param name="EmployeeList"></param>
        /// <returns>bool result indicates if the employee is added successfully or not</returns>
        public bool AddEmployee(string employee, List<IEmployee> EmployeeList)
        {
            bool Result = false;
            string[] namesArray = employee.Split(',');
            int ArrayLength = namesArray.Length;
            if (ArrayLength == 4)
            {
            string command = namesArray[0];
            int Emp_id = Convert.ToInt32(namesArray[1]);
            string Emp_Name = namesArray[2];
            int manager_id = Convert.ToInt32(namesArray[3]);
            if (command == "add")
            {
                if (EmployeeList.Count == 0)
                {
                    IEmployee objemployee = new Employee(Emp_id, Emp_Name, manager_id);
                    EmployeeList.Add(objemployee);
                }
                else if (EmployeeList.Count >= 1)
                {
                    var empid = EmployeeList.Where(x => x.EmployeeId == manager_id).ToList();
                    var empidnew = EmployeeList.Where(x => x.EmployeeId == Emp_id).ToList();

                    if ((empid.Count == 0) || (manager_id == -1))
                    {
                        manager_id = -1;
                    }

                    if (empidnew.Count == 0)
                    {
                        IEmployee objemployee = new Employee(Emp_id, Emp_Name, manager_id);
                        EmployeeList.Add(objemployee);
                        Result = true;
                    }
                    else
                        Console.WriteLine("Already the employee id added. The employee id: " + Emp_id);
                }

            }
            else

                Console.WriteLine("The command of the entered employee is wrong. EmployeeId is: " + Emp_id);
            }
            else
                Console.WriteLine("The format of the entered employee is wrong.");

            return Result;

        }

        /// <summary>
        /// Supporting method to ViewEmployee
        /// </summary>
        /// <param name="emp"></param>
        /// <param name="map"></param>
        /// <param name="space"></param>
       public void printOrg(IEmployee emp,Dictionary<int,List<IEmployee>> map,string space){
            
             Console.WriteLine(space + emp.EmployeeName+" "+"["+emp.EmployeeId+"]\n");

             if (map.TryGetValue(emp.EmployeeId, out var tmplist))
                {    
                foreach(var empp in tmplist){
                            printOrg(empp,map,space+"  "); 
                    }   
                }
       }

        /// <summary>
        /// Method to view the employees in heirarchy
        /// </summary>
        /// <param name="emplist"></param>
        public void ViewEmployee(List<IEmployee> emplist)
        {
            Dictionary<int, List<IEmployee>> map = new Dictionary<int, List<IEmployee>>();
            //constructing a map of employee heirarchy
            foreach (var emp in emplist)
            {
                if (map.TryGetValue(emp.ManagerId, out var tmplist))
                {
                    tmplist.Add(emp);
                }
                else
                {
                    map.Add(emp.ManagerId, new List<IEmployee>() { emp });
                }
            }

             if (map.TryGetValue(-1, out var list))
                {
                    foreach(var emp in list){
                        printOrg(emp,map,"");
                    }   
                }

            
        }

        /// <summary>
        /// Method which return the count of employees which working directly or indirectly
        /// </summary>
        /// <param name="Employee"></param>
        /// <param name="emplist"></param>
        /// <returns>Count</returns>
        public int CountEmployee(string Employee, List<IEmployee> emplist)
        {
            Dictionary<int, List<int>> map = new Dictionary<int, List<int>>();
            //constructing a map of employee heirarchy
            foreach (var emp in emplist)
            {
                if (emp.EmployeeId < 0) continue;

                if (map.TryGetValue(emp.ManagerId, out var tmplist))
                {
                    tmplist.Add(emp.EmployeeId);
                }
                else
                {
                    map.Add(emp.ManagerId, new List<int>() { emp.EmployeeId });
                }
            }
            string[] namesArray = Employee.Split(',');
            int ArrayLength = namesArray.Length;
            if (ArrayLength == 2)
            {
            string command = namesArray[0];
            int Emp_id = Convert.ToInt32(namesArray[1]);
            if (command == "count")
            {
                List<IEmployee> list = new List<IEmployee>();
                Queue myQueue = new Queue();
                myQueue.Enqueue(Emp_id);
                int Count = -1;
                while (myQueue.Count != 0)
                {
                    Count++;
                    int num = (int)myQueue.Dequeue();
                    if (map.TryGetValue(num, out var tmplist))
                    {
                        foreach (var emp in tmplist)
                        {
                            myQueue.Enqueue(emp);
                        }
                    }
                }
                return Count;
            }
            else {
                Console.WriteLine("The command of the count employee is wrong. EmployeeId is: " + Emp_id);
            }
            }
            else
                Console.WriteLine("The format of the command is wrong.");
            return 0;
        }

        /// <summary>
        /// Method which used to move the employee from one manager to another or make it as a manager
        /// </summary>
        /// <param name="employee"></param>
        /// <param name="emplist"></param>
        /// <returns>bool result indicates if the employee is moved successfully or not</returns>
        public bool MoveEmployee(string employee, List<IEmployee> emplist)
        {
            bool Result = false;
            string[] namesArray = employee.Split(',');
            int ArrayLength = namesArray.Length;
            if (ArrayLength == 3)
            {
            string command = namesArray[0];
            int Emp_id = Convert.ToInt32(namesArray[1]);
            int manager_id = Convert.ToInt32(namesArray[2]);
            if (command == "move")
            {
                if (emplist.Count >= 1)
                {
                    var empmanagerdetails = emplist.Where(x => x.EmployeeId == manager_id).ToList();
                    var empdetails = emplist.Where(x => x.EmployeeId == Emp_id).ToList();

                    if ((empmanagerdetails.Count > 0)||(manager_id==-1))
                    {
                        if (empdetails.Count == 1)
                        {
                            foreach (var emp in empdetails)
                            {
                                emp.ManagerId = manager_id;
                                Result = true;
                                break;
                            }
                        }
                        else
                            Console.WriteLine("The given employee id is not found: " + Emp_id);
                    }
                    else
                        Console.WriteLine("The given manager id is not found: "+ manager_id);
                }
                else
                    Console.WriteLine("No records found");
            }
            else
                Console.WriteLine("The command of the entered employee is wrong. EmployeeId is: " + Emp_id);
            }
            else
                Console.WriteLine("The format of the command is wrong.");
            return Result;

        }
        /// <summary>
        /// Method used to remove a employee from the list.
        /// </summary>
        /// <param name="employee"></param>
        /// <param name="emplist"></param>
        /// <returns>bool result indicates if the employee is removed successfully or not</returns>
        public bool RemoveEmployee(string employee, List<IEmployee> emplist)
        {
            bool Result = false;
            string[] namesArray = employee.Split(',');
            int ArrayLength = namesArray.Length;
            if (ArrayLength == 2)
            {
            string command = namesArray[0];
            int Emp_id = Convert.ToInt32(namesArray[1]);
            if (command == "remove")
            {
                if (emplist.Count >= 1)
                {
                    var empdetails = emplist.Where(x => x.EmployeeId == Emp_id).ToList();
                    if (empdetails.Count == 1)
                    {
                        foreach (var emp in empdetails)
                        {
                            int Manager_id = emp.ManagerId;
                            var listofreportees = emplist.Where(x => x.ManagerId == Emp_id).ToList();
                            if (listofreportees.Count > 0)
                            {
                                foreach (var listemp in listofreportees)
                                {
                                    listemp.ManagerId = Manager_id;
                                }
                            }
                        }
                        var empdetailsforremove = emplist.SingleOrDefault(x => x.EmployeeId == Emp_id);
                        emplist.Remove(empdetailsforremove);
                        Result = true;
                    }
                    else
                        Console.WriteLine("The given employee id is not found: " + Emp_id);
                }
                else

                    Console.WriteLine("No records found");
            }
            else
                Console.WriteLine("The command of the entered employee is wrong. EmployeeId is: " + Emp_id);
            }
            else
                Console.WriteLine("The format of the command is wrong.");
            return Result;

        }

    }
}
