﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    interface IEmployee
    {
         int EmployeeId { get; set; }
         string EmployeeName { get; set; }
         int ManagerId { get; set; }
    }
}
