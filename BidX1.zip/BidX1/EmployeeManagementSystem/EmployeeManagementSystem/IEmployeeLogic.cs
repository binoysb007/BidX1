﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    interface IEmployeeLogic
    {
        bool AddEmployee(string employee,List<IEmployee>emplist);
        bool MoveEmployee(string employee, List<IEmployee> emplist);
        void ViewEmployee(List<IEmployee> emplist);
        bool RemoveEmployee(string employee, List<IEmployee> emplist);
        int CountEmployee(string Employee, List<IEmployee> emplist);
    }
}
