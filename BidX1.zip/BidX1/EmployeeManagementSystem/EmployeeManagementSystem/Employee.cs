﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    class Employee: IEmployee
    {
        private int Employee_Id;

        public int EmployeeId
        {
            get { return Employee_Id; }
            set { Employee_Id = value; }
        }

        private string Employee_Name;

        public string EmployeeName
        {
            get { return Employee_Name; }
            set { Employee_Name = value; }
        }
        private int Manager_Id;
        public int ManagerId
        {
            get { return Manager_Id; }
            set { Manager_Id = value; }
        }
        public Employee(int emp_id, string emp_Name, int manager_id)
        {
            this.EmployeeId = emp_id;
            this.EmployeeName = emp_Name;
            this.ManagerId = manager_id;
        }

    }
}
