﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // Please change the source of the file if you tried in another computer. 
            string fileName = @"C:\Users\BinoySugatha\Desktop\Testfile\EmployeeDetails.txt";
            List<IEmployee> EmployeeList = new List<IEmployee>();
            try
            {
                if (System.IO.File.Exists(fileName))
                {
                    using (System.IO.StreamReader sr = System.IO.File.OpenText(fileName))
                    {
                        var lines = File.ReadLines(fileName);
                        foreach (var line in lines)
                        {
                            string[] namesArray = line.Split(',');
                            int ArrayLength = namesArray.Length;
                            if (ArrayLength == 4)
                            {
                            string command = namesArray[0];
                            int Emp_id = Convert.ToInt32(namesArray[1]);
                            string Emp_Name = namesArray[2];
                            int manager_id = Convert.ToInt32(namesArray[3]);
                            if (command == "add")
                            {
                                if (EmployeeList.Count == 0)
                                {
                                    IEmployee objemployee = new Employee(Emp_id, Emp_Name, manager_id);
                                    EmployeeList.Add(objemployee);
                                }
                                else if (EmployeeList.Count >= 1)
                                {
                                    var empid = EmployeeList.Where(x => x.EmployeeId == manager_id).ToList();
                                    var empidnew = EmployeeList.Where(x => x.EmployeeId == Emp_id).ToList();

                                    if ((empid.Count == 0) || (manager_id == -1))
                                    {
                                        manager_id = -1;
                                    }
                                    if (empidnew.Count == 0)
                                    {
                                        IEmployee employee = new Employee(Emp_id, Emp_Name, manager_id);
                                        EmployeeList.Add(employee);
                                    }
                                    else
                                        Console.WriteLine("Already the employee id added. The employee id: " + Emp_id);
                                }
                            }
                            else
                                Console.WriteLine("The command of the entered employee is wrong. EmployeeId is: " + Emp_id);
                            }
                            else
                                Console.WriteLine("The format of the entered employee is wrong.");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("File not found");
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error in flie reading");
            }
            if (EmployeeList.Count >= 1)
            {
                int Choice = 0;
                do
                {
                    try
                    {
                        Console.WriteLine("A menu driven application for Company Employee Operations \n\n");
                        Console.Write("-------------------------------------------------------------------------\n");
                        Console.Write("\nHere are the options :\n");
                        Console.Write("1-Add an Employee.\n");
                        Console.Write("2-View Employee.\n");
                        Console.Write("3-Moving an Employee.\n");
                        Console.Write("4-Removing an Employee.\n");
                        Console.Write("5-Employee Count.\n");
                        Console.Write("6-Exit.\n");
                        Console.Write("\nInput your choice :");
                        Choice = Convert.ToInt32(Console.ReadLine());
                        switch (Choice)
                        {
                            case 1:
                                Console.WriteLine("Please enter the employee details.(Format:add,<employee id>,<name>,<manager id> Eg:add,7,Denice Maher,10)");
                                string Employeedetails = Console.ReadLine();
                                IEmployeeLogic objemp = new EmployeeLogic();
                                bool result = objemp.AddEmployee(Employeedetails, EmployeeList);
                                if (result)
                                {
                                    Console.WriteLine("The employee details are added successfully\n\n");
                                }
                                else
                                    Console.WriteLine("The employee details are not added");
                                break;
                            case 2:
                                Console.WriteLine("Employee Details View \n");
                                Console.Write("-------------------------------------------------------------------------\n");
                                IEmployeeLogic objemployee = new EmployeeLogic();
                                objemployee.ViewEmployee(EmployeeList);

                                break;
                            case 3:
                                IEmployeeLogic employeemove = new EmployeeLogic();
                                Console.WriteLine("Please enter the employee's details need to move.(Format:move,<employee id>,<new manager id>  , Eg:move,7,10)");
                                string EmployeeMove = Console.ReadLine();
                                bool ResultMove = employeemove.MoveEmployee(EmployeeMove, EmployeeList);
                                if (ResultMove)
                                {
                                    Console.WriteLine("The employee details are moved successfully\n\n");
                                }
                                else
                                    Console.WriteLine("The employee details are not moved. Please try again\n");
                                break;
                            case 4:
                                IEmployeeLogic employeeremove = new EmployeeLogic();
                                Console.WriteLine("Please enter the employee's details need to move.(Format:remove,<employee id>  , Eg:remove,7)");
                                string EmployeeRemovedetails = Console.ReadLine();
                                bool ResultRemove = employeeremove.RemoveEmployee(EmployeeRemovedetails, EmployeeList);
                                if (ResultRemove)
                                {
                                    Console.WriteLine("The employee details are removed successfully\n\n");
                                }
                                else
                                    Console.WriteLine("The employee details are not removed. Please try again\n");
                                break;
                            case 5:
                                IEmployeeLogic employee = new EmployeeLogic();
                                Console.WriteLine("Please enter the employee's id need to be find the count.(Format:count,<employee id>, Eg:count,7)");
                                string Employee = Console.ReadLine();
                                int Result = employee.CountEmployee(Employee, EmployeeList);
                                Console.WriteLine("The employee has " + Result + " reportees");
                                break;
                        }
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Wrong choice/Wrong comment.Please try again");
                    }
                } while (Choice<6);
            }
            else
                Console.WriteLine("No Employees found in the record");
                Console.ReadLine();
        }
    }
}
