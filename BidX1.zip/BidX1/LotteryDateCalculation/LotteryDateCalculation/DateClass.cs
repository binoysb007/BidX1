﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LotteryDateCalculation
{
    public class DateClass: IDateClass
    {
        private string day;
        public string Day
        {
            get { return day; }
            set { day = value; }
        }
        private DateTime lotterydate;
        public DateTime LotteryDate
        {
            get { return lotterydate; }
            set { lotterydate = value; }
        }
        public DateClass(string result, DateTime dateValue)
        {
            this.Day = result;
            this.LotteryDate = dateValue;
        }
       

    }
}
