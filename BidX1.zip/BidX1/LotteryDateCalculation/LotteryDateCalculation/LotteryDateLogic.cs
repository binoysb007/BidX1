﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LotteryDateCalculation
{
    class LotteryDateLogic: ILotteryDateLogic
    {
        List<IDateClass> datelist = new List<IDateClass>();
        /// <summary>
        /// Lottery Date calculation using Current date
        /// </summary>
        /// <returns>Date class</returns>
        public List<IDateClass> LotteryDateLogicCalculationWithCurrentDate()
        {
            string Result = string.Empty;
            CultureInfo objCulture = Thread.CurrentThread.CurrentCulture;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("es-ES");
            DateTime dateValue = System.DateTime.Now;
            Result = dateValue.DayOfWeek.ToString();
            if ((Result == "Wednesday") || (Result == "Saturday"))
            {
                IDateClass idate = new DateClass(Result, dateValue);
                datelist.Add(idate);
            }
            if ((Result == "Monday") || (Result == "Thursday"))
            {
                DateTime LotteryDate = dateValue.AddDays(2);
                Result = LotteryDate.DayOfWeek.ToString();
                IDateClass idate = new DateClass(Result, LotteryDate);
                datelist.Add(idate);
            }
            if ((Result == "Tuesday") || (Result == "Friday"))
            {
                DateTime LotteryDate = dateValue.AddDays(1);
                Result = LotteryDate.DayOfWeek.ToString();
                IDateClass idate = new DateClass(Result, LotteryDate);
                datelist.Add(idate);
            }
            if (Result == "Sunday")
            {
                DateTime LotteryDate = dateValue.AddDays(3);
                Result = LotteryDate.DayOfWeek.ToString();
                IDateClass idate = new DateClass(Result, LotteryDate);
                datelist.Add(idate);
            }
            Thread.CurrentThread.CurrentCulture = objCulture;
            return datelist;
        }
        /// <summary>
        /// Lottery Date calculation using custom date
        /// </summary>
        /// <param name="CustomDate"></param>
        /// <returns>Date class</returns>
        public List<IDateClass> LotteryDateLogicCalculationWithCustomDate(DateTime CustomDate)
        {
            string Result = string.Empty;
            CultureInfo objCulture = Thread.CurrentThread.CurrentCulture;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("es-ES");
            DateTime dateValue = CustomDate;
            Result = dateValue.DayOfWeek.ToString();
            if ((Result == "Wednesday") || (Result == "Saturday"))
            {
                IDateClass idate = new DateClass(Result, dateValue);
                datelist.Add(idate);
            }
            if ((Result == "Monday") || (Result == "Thursday"))
            {
                DateTime LotteryDate = dateValue.AddDays(2);
                Result = LotteryDate.DayOfWeek.ToString();
                IDateClass idate = new DateClass(Result, LotteryDate);
                datelist.Add(idate);
            }
            if ((Result == "Tuesday") || (Result == "Friday"))
            {
                DateTime LotteryDate = dateValue.AddDays(1);
                Result = LotteryDate.DayOfWeek.ToString();
                IDateClass idate = new DateClass(Result, LotteryDate);
                datelist.Add(idate);
            }
            if (Result == "Sunday")
            {
                DateTime LotteryDate = dateValue.AddDays(3);
                Result = LotteryDate.DayOfWeek.ToString();
                IDateClass idate = new DateClass(Result, LotteryDate);
                datelist.Add(idate);
            }
            Thread.CurrentThread.CurrentCulture = objCulture;
            return datelist;
        }
    }
}
