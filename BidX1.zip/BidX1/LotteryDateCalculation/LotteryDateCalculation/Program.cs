﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LotteryDateCalculation
{
    class Program
    {
        static void Main(string[] args)
        {
            ILotteryDateLogic objILotteryDateLogic = new LotteryDateLogic();
            String Result = String.Empty;
            int Choice = 0;
            do
            {
                try
                {
                    Console.Write("A menu driven application to calculate the LotteryDate:\n");
                    Console.Write("-------------------------------------------------------------------------");
                    Console.Write("\nHere are the options :\n");
                    Console.Write("1-Use Current Date.\n");
                    Console.Write("2-Custom Date.\n");
                    Console.Write("3-Exit.\n");
                    Console.Write("\nInput your choice :");
                    Choice = Convert.ToInt32(Console.ReadLine());
                    switch (Choice)
                    {
                        case 1:
                            try
                            {
                                List<IDateClass> datelist = objILotteryDateLogic.LotteryDateLogicCalculationWithCurrentDate();
                                foreach (DateClass dateClass in datelist)
                                {
                                    Console.WriteLine("The next Lottery Date is: " + dateClass.LotteryDate.ToShortDateString() + " at 8 P.M");
                                    Console.WriteLine("The next Lottery Day is: " + dateClass.Day);
                                }
                                datelist.Clear();
                                Console.ReadLine();
                            }
                            catch (Exception)
                            {

                                Console.WriteLine("Unknown date format.Please try again");
                            }
                            break;
                        case 2:
                            try
                            {
                                Console.Write("Please enter the date.(dd-mm-yyyy)format\n");
                                DateTime CustomDate = Convert.ToDateTime(Console.ReadLine());
                                List<IDateClass> datelistcase = objILotteryDateLogic.LotteryDateLogicCalculationWithCustomDate(CustomDate);
                                foreach (DateClass dateClass in datelistcase)
                                {
                                    Console.WriteLine("The next Lottery Date is: " + dateClass.LotteryDate.ToShortDateString() + " at 8 P.M");
                                    Console.WriteLine("The next Lottery Day is: " + dateClass.Day);
                                }
                                datelistcase.Clear();
                                Console.ReadLine();
                            }
                            catch (Exception)
                            {

                                Console.WriteLine("Unknown date format.Please try again");
                            }
                            break;

                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Wrong choice.Please try again");
                } 
            } while (Choice<3);


            
        }
    }
}
