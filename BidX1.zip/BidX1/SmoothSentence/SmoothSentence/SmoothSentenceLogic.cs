﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmoothSentence
{
    class SmoothSentenceLogic: ISmoothSentence
    {
        public bool SmoothSentence(String Smoothsentence)
        {
            bool Result=false;
            int i,c=0,WordCount=0,Counter=0;
            try
            {
                while (c <= Smoothsentence.Length - 1)
                {
                    if (Smoothsentence[c] == ' ' || Smoothsentence[c] == '\n' || Smoothsentence[c] == '\t')
                    {
                        WordCount++;
                    }
                    c++;
                }
                for (i = 0; i < Smoothsentence.Length; i++)
                {
                    if (Smoothsentence[i] == ' ')
                    {
                        if (Smoothsentence[i - 1] == Smoothsentence[i + 1])
                        {
                            Counter++;
                        }
                        if ((WordCount == Counter) && (WordCount != 0) && (Counter != 0))
                        {
                            Result = true;
                        }
                        else

                            Result = false;
                    }
                }
            }
            catch (Exception)
            {

                Console.WriteLine("Error encountered. Please try again");
            }

            return Result;
           
        }
    }
}
