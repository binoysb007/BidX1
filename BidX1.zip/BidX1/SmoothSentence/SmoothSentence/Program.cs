﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmoothSentence
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the Sentence");
            String Sentence = Console.ReadLine();
            ISmoothSentence objsmoothSentence = new SmoothSentenceLogic();
            bool Result= objsmoothSentence.SmoothSentence(Sentence);
            if (Result)
            {
                Console.WriteLine("Its a Smooth Sentence ");
            }

            else
                Console.WriteLine("Its not a Smooth Sentence ");

            Console.ReadLine();
        }
    }
}
