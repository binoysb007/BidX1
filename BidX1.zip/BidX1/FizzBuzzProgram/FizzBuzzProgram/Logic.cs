﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzzProgram
{
    public class Logic: ILogic
    {
        public void FizzProgram()
        {
            try
            {
                for (int Number = 1; Number <= 100; Number++)
                {
                    if (Number % 3 == 0 && Number % 5 == 0)
                    {
                        Console.WriteLine("The Number " + Number + " is FizzBuzz");
                    }
                    else if (Number % 3 == 0)
                    {
                        Console.WriteLine("The Number " + Number + " is Fizz");
                    }
                    else if (Number % 5 == 0)
                    {
                        Console.WriteLine("The Number " + Number + " is Buzz");
                    }
                    else
                        Console.WriteLine("The Number " + Number + " is Not the multiple of 3 or 5");
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Error encountered please try again ");
            }

        }
    }
}
