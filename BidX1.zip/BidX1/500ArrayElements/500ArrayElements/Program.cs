﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _500ArrayElements
{
    class Program
    {
        static void Main(string[] args)
        {
            int Number = 500;
            int[] NumArray = new int[Number];

            //creating an array of integers 1 to n
            for (int i = 0; i < Number; i++)
            {
                NumArray[i] = i + 1;
            }

            //randomizing array
            Random objrandom = new Random();
            int[] RandomArray = NumArray.OrderBy(x => objrandom.Next()).ToArray();

            //selecting and removing arnitrary value from array
            int RandomIndex = objrandom.Next(0, Number);
            var ArrayList = new List<int>(RandomArray);
            foreach (int iterationNumber in ArrayList)
            {
                Console.WriteLine("The list of random generated numbers are: "+iterationNumber);
            }

            ArrayList.RemoveAt(RandomIndex);
            RandomArray = ArrayList.ToArray();
            
            foreach (int iterationNumber in RandomArray)
            {
                Console.WriteLine("The list of random generated numbers after delete are: " + iterationNumber);
            }

            //Sum of 'n' Naturals Numbers is n(n+1)/2
            int TotalSum = (Number * (Number + 1)) / 2;

            //calculating sum of the arraylist after removal of element
            int SumArrayAfterDelete = 0;
            foreach (int i in RandomArray) SumArrayAfterDelete += i;

            // The value removed will be equal to the difference between the sum on n natural numbers and the sum of current array
            int DeletedIndexValue = TotalSum - SumArrayAfterDelete;
            Console.Write("\n\n");
            Console.Write("The removed randomly generated number from the arraylist is: "+ DeletedIndexValue);
            Console.Write("\n\n");
            Console.Write("\n\n");
            Console.WriteLine("The randomly selected index is: " + RandomIndex);
            Console.Write("\n\n");
            Console.ReadLine();
        }
    }
}
